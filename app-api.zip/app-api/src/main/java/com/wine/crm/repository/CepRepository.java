package com.wine.crm.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.wine.crm.model.Cep;

@Repository
public interface CepRepository extends JpaRepository<Cep, Long> {

	@Query(" FROM Cep WHERE :faixa BETWEEN faixaInicio AND faixaFim")
	Cep findByFaixa(@Param("faixa") Long faixa);

	@Query(" FROM Cep WHERE ((faixaInicio BETWEEN :inicio AND :fim OR faixaFim BETWEEN :inicio AND :fim) OR (:inicio BETWEEN faixaInicio AND faixaFim OR :fim BETWEEN faixaInicio AND faixaFim)) AND (id <> :id OR :id IS NULL)")
	List<Cep> findByIntervalo(@Param("inicio") Long inicio, @Param("fim") Long fim, @Param("id") Long id);

}
