package com.wine.crm.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wine.crm.model.Cep;
import com.wine.crm.repository.CepRepository;

@Service
public class AppService {

	@Autowired
	private CepRepository cepRepository;

	public Cep findByFaixa(Long faixa) throws Exception {
		return cepRepository.findByFaixa(faixa);
	}

	public Cep insertUpdate(Cep cep) throws Exception {
		if (cep.getFaixaInicio() <= cep.getFaixaFim()) {
			List<Cep> ceps = cepRepository.findByIntervalo(cep.getFaixaInicio(), cep.getFaixaFim(), cep.getId());

			if (ceps.isEmpty()) {
				return cepRepository.save(cep);
			} else {
				throw new Exception("Já existe um CEP cadastrado para essa faixa");
			}
		} else {
			throw new Exception("A faixa de início deve ter um valor menor do que a o da faixa fim!");
		}
	}

	public void delete(Long id) throws Exception {

		try {
			cepRepository.deleteById(id);
		} catch (Exception e) {
			throw new Exception("Não existe um CEP cadastrado com esse ID");
		}
	}

	public List<Cep> findAll() {
		return cepRepository.findAll();
	}

}
