package com.wine.crm.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.lang.NonNull;

@Entity
@Table
public class Cep {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NonNull
	@Column(nullable = false)
	private String codigoLoja;
	
	@NonNull
	@Column(nullable = false)
	private Long faixaInicio;
	
	@NonNull
	@Column(nullable = false)
	private Long faixaFim;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCodigoLoja() {
		return codigoLoja;
	}

	public void setCodigoLoja(String codigoLoja) {
		this.codigoLoja = codigoLoja;
	}

	public Long getFaixaInicio() {
		return faixaInicio;
	}

	public void setFaixaInicio(Long faixaInicio) {
		this.faixaInicio = faixaInicio;
	}

	public Long getFaixaFim() {
		return faixaFim;
	}

	public void setFaixaFim(Long faixaFim) {
		this.faixaFim = faixaFim;
	}
	
}
